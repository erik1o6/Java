
/** 
* Name:  ERIK ARFVIDSON
* Section: 001 
* Program: Lab 10 
* Date: 10/27/2012
**/

import java.awt.BorderLayout;
import javax.swing.*;
import java.awt.GridLayout;

/**
Lab10
@author ERIK ARFVIDSON 
@version 10/27/2012 
**/

@SuppressWarnings("serial")
public class lab10 extends JApplet
{
	private static final int ASIZE = 16;	
		
	private JButton buttonArray[];		
	private BorderLayout textLayout;		
	private GridLayout buttonLayout;	
	private JPanel upPanel;				
	private JPanel midPanel;			
	private JTextField textField;			
	
	@Override
	public void init()
	{
		textLayout = new BorderLayout();
		setLayout(textLayout);
		buttonArray = new JButton[ASIZE];//setups array of jbuttons
		
		//creates the text field
		textField = new JTextField();
		
		//fill the array information with jbuttons
		buttonArray[0] = new JButton("7");
		buttonArray[1] = new JButton("8");
		buttonArray[2] = new JButton("9");
		buttonArray[3] = new JButton("/");
		buttonArray[4] = new JButton("4");
		buttonArray[5] = new JButton("5");
		buttonArray[6] = new JButton("6");
		buttonArray[7] = new JButton("*");
		buttonArray[8] = new JButton("1");
		buttonArray[9] = new JButton("2");
		buttonArray[10] = new JButton("3");
		buttonArray[11] = new JButton("-");
		buttonArray[12] = new JButton("0");
		buttonArray[13] = new JButton("+/-");
		buttonArray[14] = new JButton("=");
		buttonArray[15] = new JButton("+");

		//Creates the up panel 
		upPanel = new JPanel();
		upPanel.setLayout(new BorderLayout());
	    upPanel.add(textField);
	    
	    //Makes the layout 4,4,5
	    buttonLayout = new GridLayout(4, 4, 5, 5);
	    
	    //Creates the middle pannel section to hold the buttons which will hold all the buttons
	    midPanel = new JPanel();
	    midPanel.setLayout(buttonLayout); 
	    //Add buttons to the midPanel
	    for(JButton num : buttonArray)
	    {
	    	midPanel.add(num);
	    }
	    //adds to the panel position holder
	    add(upPanel, BorderLayout.NORTH);
	    add(midPanel, BorderLayout.CENTER);
	}
}
