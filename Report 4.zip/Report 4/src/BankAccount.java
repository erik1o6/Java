/**
 * Name: Erik Arfvidson 
 * Section: Program: 
 * Lab 4 
 * Date: 9/8/2012
 **/

public class BankAccount {
	private String name;
	private double balance;
	private String accountType; // The account type either checking or savings

	public BankAccount()// Default
	{
		this(" ", 0.0, "checking");
	}

	public BankAccount(String type)// Set type of account
	{
		this(" ", 0.0, "type");
	}

	public BankAccount(double amount)// set an amount of money to the type
	{
		this(" ", amount, "checking");
	}

	public BankAccount(String name, double balance, String accountType)// Bank account created with the name,balance, accountType
	{
		this.name = name;

		if (balance > 0) {
			this.balance = balance;
		} else {
			balance = 0.0;
		}

		this.accountType = accountType;
	}

	public Boolean Withdraw(double amount)// Withdraw money from the bank account
	{
		if (amount <= balance) {
			this.balance = balance - amount;
			return true;
		}

		else {
			return false;
		}
	}

	public double GetBalance() // returns from the account

	{
		return balance;
	}

	public String GetType()
	// returns type of accounts
	{
		return accountType;
	}

	public void DisplayBalance() // Display account balance

	{
		System.out.printf("Your balance is $%.2f\n", balance);
	}

	public String toString()// returns the account information to string

	{
		String info;

		info = "\nname: " + this.name;
		info += "\nYour BankAccount's type is: " + this.accountType;
		info += "\nYour balance is currently: " + this.balance;

		return info;
	}

	public static void main(String[] args) {
		// the BankAccount to the test the program
		BankAccount John;

		// 1:test constructors
		John = new BankAccount("Erik", 100, "Saving");

		System.out.println(John.toString());
		// Test the default constructor

		John = new BankAccount();
		System.out.println(John.toString());

		John = new BankAccount(100);
		System.out.println(John.toString());

		// Part3: test the withdraw
		John = new BankAccount(100);

		// test withdraw for 3 times
		for (int i = 0; i < 3; i++) 
		{
			System.out.println("Now try to withdraw $50. ");
			if (John.Withdraw(50)) 
			{
				System.out.println("Withdraw successfully. ");
				John.DisplayBalance();
			} 
			else
			{
				System.out.println("Unable to withdraw, insufficient funds");
			}
		}
	}
}
