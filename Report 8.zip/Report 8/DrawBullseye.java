import java.awt.Graphics;
import java.awt.Color;
import java.awt.BorderLayout;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.ImageIcon;

public class DrawBullseye 
{
//Color Selection
public Random rand = new Random();//Random 
float r = rand.nextFloat();//Red
float gs = rand.nextFloat();//Green
float b = rand.nextFloat();//Blue
public Color randomColo1rss = new Color(.5f*r, .5f*gs, .5f*b);//Circle Color
public Color randomColors = new Color(r, gs, b);// Second Circle Color



	public DrawBullseye(Graphics g, int x, int y, int diam, int count ) {
		// PRE:  g !=null, x!=null, y!=null, diam!=null, count!=null
		// POST: Draws BULLSEYE

	    int r = diam;   // because fillOval uses width and height, use diam here
	    int xloc = x;// Controls the X coordinate of the center of the circle
	    int yloc = y;// Controls the X coordinate of the center of the circle
	    boolean change = true;// If the panel resizes
	    
	    
	    for(int j=0;j<count;j++) {
	        int offset = (int)(r*(j*(1/(float)count)));
	        if(change) {
	            g.setColor(randomColo1rss);//set color
	            change = false;
	        } else {
	            g.setColor(randomColors);//set color
	            change = true;
	        }
	        g.fillOval(xloc+offset/2, yloc+offset/2, r-offset, r-offset);
	    }
	}
}
