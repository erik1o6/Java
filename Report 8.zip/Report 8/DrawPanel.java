import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import java.util.Random;

public class DrawPanel extends JPanel
{
	public Random rand = new Random();

   	float rd = rand.nextFloat();
   	float gsd = rand.nextFloat();
   	float bd = rand.nextFloat();

	public Color randomColo1r = new Color(rd, gsd, bd);
    public DrawPanel() {                      // set up graphics window
       super();    
	// this can be omitted
       setBackground(Color.white);
    }
    
    @SuppressWarnings("deprecation")
	@Override
    public void paintComponent(Graphics g) { 
		// PRE:  g !=null 
		// POST: Draws Object
        int width = getWidth();              // width of window in pixels
        int height = getHeight();            // height of window in pixels
        super.paintComponent(g);              // call superclass to make panel display correctly
        // Drawing code goes here
        // Notice that you should call super.paintComponent method before you start drawing
        // Otherwise, what's been done in the super will cover your drawing
        Font font = new Font("Verdana", Font.BOLD, 16);// Font
    	FontMetrics fm   = g.getFontMetrics(font);//  Font Metrics
    	String s= "Erik Arfvidson";// Text
    	 
		java.awt.geom.Rectangle2D rect = fm.getStringBounds(s, g);
	 	int textHeight = (int)(rect.getHeight()); // The Height of text
    	int textWidth  = (int)(rect.getWidth());// The width of text
    	int panelHeight= this.getHeight();// The Height of the panel
    	int panelWidth = this.getWidth();// The Width of the panel
    	int radius=0;

    	// Center Bullseye horizontally and vertically dynamically
    	if(panelHeight<panelWidth)
    	{
    		 radius = (panelHeight)  / 2;

    	}
    	else if(panelHeight>panelWidth)
    	{
    		 radius = (panelWidth)  / 2;
    		 
    	}
    	int x2 = (panelWidth / 2)-radius;// X coordinate of bullseye
    	int y2 = (panelHeight/ 2)-radius;//Y coordinate of bullseye
     	DrawBullseye ss =new DrawBullseye(g,x2,y2,radius*2,12);// Draw BullSeye	
     	
    	int y =50 - textHeight; // Y coordinate of text
    	int x = (panelWidth-textWidth)  / 2;// X coordinate of text
     	g.setColor(randomColo1r);  // Set string Color
     	g.setFont(font);//Set String Font
     	g.drawString(s, x, y);  // Draw the string.
     	
    }

    public static void main(String[] args)
    {	   
        DrawPanel panel = new DrawPanel();                            // window for drawing
        JFrame application = new JFrame();                            // the program itself       
        application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   // set frame to exit
                                                                     // when it is closed
        application.add(panel);           

        application.setSize(500, 400);         // window is 500 pixels wide, 400 high
        application.setVisible(true);  
       
    }



}